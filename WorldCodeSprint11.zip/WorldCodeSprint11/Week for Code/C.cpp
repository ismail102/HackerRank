#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    while(cin>>n)
    {
        int nums;
        vector<string>vc[1000],ans[1000];
        string str[25],st;
        map<string,int>mp,name;
        map<int,string>mpp;
        map<string,int>number;
        int c=0;
        for(int i=0;i<n;i++){
            cin>>str[i];
            name[str[i]]++;

            if(name[str[i]]==1){
                mp[str[i]]=++c;
                mpp[c]=str[i];
                number.clear();
            }
            cin>>nums;
            for(int j=0;j<nums;j++){
                cin>>st;
                number[st]++;
                if(number[st]==1){
                    //cout<<str[i]<<' '<<st<<endl;
                    vc[c].push_back(st);
                }
            }
        }
       // cout<<c<<endl;
        for(int i=1;i<=c;i++){
            map<string,bool>vis;
            for(int j=0;j<vc[i].size();j++){
                    bool f=false;
                for(int k=0;k<vc[i].size();k++){
                    if(vc[i][j].size()<vc[i][k].size()){
                            int cnt=0;
                            //cout<<mpp[i]<<' '<<vc[i][j]<<' '<<vc[i][k]<<endl;
                        for(int l=vc[i][j].size()-1,m=vc[i][k].size()-1;l>=0;l--,m--){
                            if(vc[i][j][l]==vc[i][k][m]){
                                    cnt++;
                               // cout<<vc[i][j][l]<<' '<<vc[i][k][m]<<endl;
                            }
                        }
                        //cout<<cnt<<' '<<vc[i][j].size()<<endl;
                        if(cnt==vc[i][j].size()){
                            f=true;break;
                        }
                    }
                }
                if(f==false){
                    cout<<vc[i][j]<<' '<<mpp[i]<<endl;
                    ans[i].push_back(vc[i][j]);
                }
            }
        }
        cout<<c<<endl;
        for(int i=c;i>=1;i--){
                cout<<mpp[i]<<' '<<ans[i].size()<<' ';
            for(int j=0;j<ans[i].size();j++)
                cout<<ans[i][j]<<' ';

            cout<<endl;
        }


    }
    return 0;
}

