#include<bits/stdc++.h>
using namespace std;
#define Max 4*1001
vector<int>ara[40002],dp[40002];
vector<int>vis[40002];
int dx[]={0,0,-1,1};
int dy[]={1,-1,0,0};
int n,m;
int ans;
int solve(int i,int j)
{

    cout<<n<<' '<<i<<endl;

    if(i>=n) return 0;

    if(vis[i][j]) return dp[i][j];

    int  p=0;
    for(int l=0;l<4;l++){
        cout<<"m"<<endl;
        int tx = dx[l] + i;
        int ty = dy[l] + j;
        if(tx>=0 and tx<=n and ty>=0 and ty<=m){
            p+=ara[i][j] + solve(tx,ty);
            ans=max(p,ans);
        }
    }
    vis[i][j]=1;
    return dp[i][j]=ans;
}
int main()
{
   cin>>n>>m;
int x;
       for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>x;
            ara[i].push_back(x);
        }
       }
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++) vis[i][j]=0;
        }
        for(int i=0;i<m;i++){
            ans=0;

            int rslt = solve(0,i);

            cout<<rslt<<endl;

        }


}
