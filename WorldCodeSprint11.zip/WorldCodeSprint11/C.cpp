#include<bits/stdc++.h>
using namespace std;
#define Max 100000 + 5
#define pii pair<int,int>
#define ll long long
int ara[505];
map<string ,map<int,bool> >mp;

int check(string str)
{
    int k=0;
    while(1)
    {
        if(mp[str][k]==false){
            mp[str][k]=true;
            return k;
        }
        k++;

    }
}

int main()
{
    //freopen("input.txt","r",stdin);
    int n,t;

    while(cin>>n)
    {
        string a,b,c,s;
        for(int i=0;i<n;i++){
            cin>>a;
            if(a=="crt"){
                cin>>b;
                int k = check(b);
                if(k==0){
                    cout<<"+ "<<b<<endl;
                }
                else{
                    cout<<"+ "<<b<<"("<<k<<")"<<endl;
                }

            }
            else if(a=="del")
            {
                s="";
                cin>>b;
                int len = b.size();

                int j=0;
                while(j<len){
                    if(b[j]=='(') break;
                    s+=b[j];
                    j++;
                }
                int N=0;
                if(j==len){
                    //cout<<b<<' '<<0<<endl;
                    cout<<"- "<<b<<endl;
                    mp[b][0]=false;
                    continue;
                }

                j++;
                while(1){
                    if(b[j]==')') break;
                    N=N*10 + b[j]-'0';
                    j++;
                }
                //cout<<s<<' '<<N<<endl;
                mp[s][N]=false;
                cout<<"- "<<b<<endl;

            }
            else if(a=="rnm"){
                s="";
                cin>>b>>c;
                int len = b.size();
                int j=0;
                while(j<len){
                    if(b[j]=='(') break;
                    s+=b[j];
                    j++;
                }
                int N=0;

                if(j==len){
                    mp[b][0]=false;

                    int k = check(c);

                    if(k==0){
                        cout<<"r "<<b<<' '<<"-> "<<c<<endl;
                    }
                    else cout<<"r "<<b<<' '<<"-> "<<c<<"("<<k<<")"<<endl;
                    continue;
                        
                }

                j++;

                while(1){
                    if(b[j]==')') break;
                    N=N*10 + b[j]-'0';
                    j++;
                }

                mp[s][N]=false;


                int k = check(c);

                if(k==0){
                    cout<<"r "<<b<<' '<<"-> "<<c<<endl;
                }
                else cout<<"r "<<b<<' '<<"-> "<<c<<"("<<k<<")"<<endl;

            }
            
            
        }
    }
    return 0;
}