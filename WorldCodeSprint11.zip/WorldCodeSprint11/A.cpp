#include<bits/stdc++.h>
using namespace std;
#define Max 100000 + 5
#define pii pair<int,int>
#define ll long long
int ara[505];
int main()
{
    int n,t;
    while(cin>>n)
    {
        for(int i=1;i<=n;i++) cin>>ara[i];
        int sum=0,sum1=0;
        for(int i=1,j=n;i<=n/2;i++,j--){
            sum+=ara[i];
            sum1+=ara[j];
        }

        cout<<abs(sum1-sum)<<endl;

    }
    return 0;
}