
#include<bits/stdc++.h>
using namespace std;
#define Max 100000 + 5
#define pii pair<int,int>
#define ll long long
int ara[3*100005];

int H[3*100005];

int main()
{

    string str;
    int n,t;
    int k,b,m;
    while(cin>>str)
    {
       cin>>k>>b>>m;

       memset(H,0,sizeof(H));

       int len = str.size();
       int sum = 0;
       for(int i=0;i<len;i++)
       {    
            sum = sum*b + (str[i] - '0');
            sum %=m;
           H[i+1]=sum; 

       }
       //for(int i=1;i<=len;i++) cout<<H[i]<<' ';
       //cout<<endl;

       int pp = 1;

       for(int i=1;i<=k;i++){
           pp*=b;
           pp%=m;
       }
       //cout<<pp<<endl;
       H[0]=0;

       int ans=0;
       for(int i=k;i<=len;i++){
            //cout<<H[i]<<' '<<H[i-k]*pp<<endl;
            ans+=(H[i] - (H[i-k]*pp)%m +  m)%m;
       }

       cout<<ans<<endl;

    }
    return 0;
}
